<script>
   $(document).ready(function(){
   				$('[data-toggle="tooltip"]').tooltip({html:true}); 
   			});
</script>
<div class="row justify-content-center col-md-12">
      <?php foreach($Engine->query("SELECT * FROM `orders` WHERE `status` = 1 ORDER BY `id` DESC LIMIT 6") as $u) { ?>
      <div class="col-6 col-lg-4 col-xl-auto" style="color: white; width: 170px">
      <div class="row justify-content-center">
         <img src="/engine/face.php?u=<?=$u['nick']?>&s=80&v=front" class="center-block img-circle img-responsive" data-placement="bottom" data-toggle="tooltip" type="button" title="" data-original-title="Игрок: <?=$u['nick']?><br>Купил: <font color='#EC971F'><?=$u['group']?></font><br>Время: <?=$Engine->date($u['date']." ".$u['time'])?><br> Статус: <span class='label label-success'>Выдано</span>">
      </div>
         <div class="text-center" style:"word-break:break-word">
            <h5><?=mb_strimwidth($u['nick'], 0, 12, "..")?></h5><small>[<?=$Engine->group($u['groupid'])->name?>]<br><?=$Engine->date($u['date']." ".$u['time'])?></small>
         </div>
      </div>
      <? } ?>
</div>
<?php>
