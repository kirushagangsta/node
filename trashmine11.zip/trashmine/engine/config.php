<?php

$config = array(
	'db' => array(	
		'db_host'     => 'alpha.divinecode.org', //IP дедика, на котором стоит сайт
		'db_user'     => '', //Юзер
		'db_pass'     => '', //Пароль
		'db_name'     => 'trashmine', //Название базы данных
	),
	
	
	'server' => array(
		'ip' => 'play.trashmine.ru', //IP сервера
		'name' => 'TrashMine', //Название сервера
		'design_name' => '<font style="color: #ff6a6a;">Trash</font><font style="color: white;">Mine</font>', //Название сервера в цвете
	),
	
	'unitpay' => array( // Настройки UnitPay
		'project_id' => '166361-03b8c', // ID(Номер) проекта || demo - в случае тестового платежа
		//Example: 'project_id' => '111111-11111'
		'key' => '', // Секретный ключ
		//Example: 'key' => '15c3524s28dcd01erga5922bdfd61dc8'
	),
);
