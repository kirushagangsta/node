<?php
/* Smarty version 3.1.30, created on 2019-08-07 10:48:37
  from "/var/www/html/templates/main.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5d4a82558a4159_59530201',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bd58f47f5b3fca8c4a39bd5fa673060c4cfc5c1d' => 
    array (
      0 => '/var/www/html/templates/main.html',
      1 => 1565163475,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.html' => 1,
  ),
),false)) {
function content_5d4a82558a4159_59530201 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<title><?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['name'];?>
 | Игровые сервера Майнкрафт (Minecraft)</title>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['name'];?>
 | Игровые сервера Майнкрафт (Minecraft)" />
		<link type="image/x-icon" rel="shortcut icon" href="favicon.ico" />
		<link type="text/css" rel="stylesheet" href="/styles/css/bootstrap.min.css" />
		<link type="text/css" rel="stylesheet" href="/styles/css/animate.min.css" />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
		<link type="text/css" rel="stylesheet" rel="stylesheet" href="/styles/css/main.css" />
	</head>
	<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container">
				<a class="navbar-brand" href="/"><?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['design_name'];?>
</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarNav">
					<ul class="navbar-nav mr-auto">
						<li class="nav-item"> <a href="/" class="nav-link"><i class="fas fa-home"></i>Главная</a> </li>
						<li class="nav-item"> <a href="https://vk.com/trashmineru" target="blank" class="nav-link"><i class="fab fa-vk"></i>Группа ВКонтакте</a> </li> 
						<li class="nav-item"> <a href="https://vk.com/topic-184730266_39448216" target="blank" class="nav-link"><i class="fab fa-vk"></i>Правила </li> 
						<li class="nav-item"> <a href="https://vk.com/topic-184730266_39448745" target="blank" class="nav-link"> <i class="fab fa-vk"></i>Описание привилегий</li>                                    
					</ul>
					<ul class="navbar-nav" id="server-info">
						<li><a href="javascript:" class="btn btn-primary btn-sm">
							Онлайн: <span id="online">0</span> / <span id="slots">0</span></a>
						</li>
						<li><a href="javascript:" class="btn btn-success btn-sm" onclick="prompt('Скопируйте наш IP адрес и вставьте в ваш клиент:','<?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['ip'];?>
'); return false;">
							IP: <?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['ip'];?>

							</a>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		<main class="container">
			<div id="action">
				<img src="/styles/img/iphonex.png" alt="Выиграй IPhone X" />
			</div>
			<article>
				<div class="row">
					<div class="col-md-6">
						<?php $_smarty_tpl->_subTemplateRender("file:messages.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

						<ul class="nav nav-tabs" role="tablist">
							<?php echo $_smarty_tpl->tpl_vars['get_servers']->value;?>

						</ul>
						<div class="panel panel-default" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
							<div class="panel-body">
								<div class="tab-content">
									<?php echo $_smarty_tpl->tpl_vars['get_form']->value;?>

								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<center>
							<div class="alert alert-warning">
								<ul>
									<li>Донат остаётся НАВСЕГДА после покупки.</li>
									<li>Действуют скидки 95% на ВЕСЬ донат.</li>
									<li>Оплата происходит БЕЗ КОМИССИИ через любые платёжные системы.</li>
									<li>Донат выдаётся МОМЕНТАЛЬНО.</li>
									<li>Работает ДОПЛАТА на все донат-услуги.</li>
								</ul>
							</div>
							<div class="alert alert-success">
								<h5 class="flash animated infinite">КУПИТЕ ДОНАТ СО СКИДКОЙ 95%<br><small>КОНСОЛЬ С ДОСТУПОМ К КИВИ <b>350</b> рублей</small></h5>
							</div>
							<p class="text-center"><b>Осталось до завершения акции:</b></p>
							<div class="row">
								<div class="col-md-4">
									<div class="card">
										<div class="card-block">
											<h5 class="second text-danger"></h5>
											Часов
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="card">
										<div class="card-block">
											<h5 class="third text-danger"></h5>
											Минут
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="card">
										<div class="card-block">
											<h5 class="four text-danger"></h5>
											Секунд
										</div>
									</div>
								</div>
							</div>
							<br>
						</center>
					</div>
				</div>
				
				<h2>Последние донатеры:</h2>
				<div class="donat" id="donaters"></div>

			</article>
		</main>
		<footer class="footer">
			<div class="container text-center">
				<?php ob_start();
echo date('Y');
$_prefixVariable1=ob_get_clean();
if (2019 != $_prefixVariable1) {?>2019 - <?php }
echo date('Y');?>
 © <?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['design_name'];?>
.
				Все права защищены! 
			</div>
		</footer>
		<div id="vk_id_info" class="modal fade" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Как узнать свой ID VK?</h4>
					</div>
					<div class="modal-body row">
						<div class="col-md-2 text-center">
							<h1>1.</h1>
						</div>
						<div class="col-md-10">
							<h3>Вам нужно перейти в специальное приложение вконтакте</h3>
							<br>
							<a href="https://vk.com/linkapp?mid=277074275" target="_blank" class="btn btn-info btn-block">Перейти к приложению (откроется в новом окне)</a>
						</div>
						<div class="col-md-2 text-center">
							<h1>2.</h1>
						</div>
						<div class="col-md-10">
							<h3>Сейчас вам нужно запустить это приложение и просто нажать кнопку узнать не вводя ничего в поде</h3>
						</div>
						<div class="col-md-2 text-center">
							<h1>3.</h1>
						</div>
						<div class="col-md-10">
							<h3>Теперь вам нужно скопировать текст, как подчеркнуто на картинке ниже! У вас он будет свой!</h3>
							<br>
							<img style="height: 200px; width: auth;" src="https://image.prntscr.com/image/_e9iVIB0ReqDtzSJOMY9Nw.png">
						</div>
						<div class="col-md-2 text-center">
							<h1>4.</h1>
						</div>
						<div class="col-md-10">
							<h3>Теперь вы можете нажать кнопку "Я понял" и вставить скопированный ID VK в нужное поле</h3>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-success" data-dismiss="modal">Я понял!</button>
					</div>
				</div>
			</div>
		</div>
		<?php echo '<script'; ?>
 src="/styles/js/jquery-3.4.0.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="/styles/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="/styles/js/countdown.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="/styles/js/script.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="/styles/js/valid.js"><?php echo '</script'; ?>
>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		<?php echo '<script'; ?>
 src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"><?php echo '</script'; ?>
>
		<![endif]-->
	</body>
</html>
<?php }
}
